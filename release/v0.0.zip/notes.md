* template : https://templatemo.com/tm-478-accord
* thème : https://fr.wikipedia.org/wiki/Jeu_math%C3%A9matique


Intro
===

À cause du covid, un musée a besoin d'une app en ligne pour gérer les oeuvres. 

Serveur LOCAL mais doit pouvoir être ouvert à internet si confinement

On visite à l'intérieur du musée et on doit pouvoir écrire sur le livre d'or par téléphone ou avoir des infos en plus.

* instruments -> extraits de sons
* musique -> concert en ligne ?
* à l'intérieur d'un instrument (au fond d'un saxophone ?)
* intérieur d'un morceau de musique

* visiter un lieu / labyrinthe en ligne ?
* monster cpu
* machine de von newmann (automate + animation)
* machines à calculer
* jeux de plateau / jeux mathématiques -> jeu des pouces / jeu de l'ange /... de conway + possibilité de jouer aux jeux
* automates
* machines de turing diverses
* de physique/animations ?


* à l'intérieur d'un corps humain
* à l'intérieur d'un cpu
* sous-marin




* morceaux de cerveau
* livres
* circ 
* poterie
* danse
* cuisine ? donner recettes
* ...



Éléments
========


* Galerie des oeuvres
* Galerie des créateurs

* Bonus section visite / labyrinthe




Base de données
===============

## Auteur
* une photo
* dates
* nom
* prénom
* nationalité


## Oeuvre 
* [CJ] auteur
* une image
* un titre
* extrait audio
* date(s)
* description


## Utilisateur (?)